package fr.cantine.beans;

public enum TypePlat {
	
	ENTREE,
	PLAT,
	ACCOMPAGNEMENT,
	DESSERT,

}
