package fr.cantine.utils;

public class GlobalErrorHandler {

}
